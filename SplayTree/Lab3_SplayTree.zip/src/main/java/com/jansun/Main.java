package com.jansun;

import com.jansun.CLI.Menu;

public class Main {

    public static void main(String[] args) {
        Menu.start();
    }
}
